package structures;

public class Test {
    public static void main(String[] args) throws Exception {
        OrderedList<Integer> lista = new OrderedList<Integer>();


        lista.insert(2);
        lista.insert(3);
        lista.insert(9);
        lista.insert(1);

        System.out.print(lista.toString()+" "+ "Maksymalna wartosc listy : " + lista.max() + "\n");

        for (Integer i: lista //foreach test
             ) {
            System.out.println(i);
        }

    }
}
