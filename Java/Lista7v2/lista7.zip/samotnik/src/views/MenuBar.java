package views;

import listeners.KeyListener;
import models.Board;
import util.Util;

import javax.swing.*;


public class MenuBar extends JMenuBar {
    private final JMenu gameMenu, moveMenu;
    private final JMenuItem mNewGame, mEnd, mSelect, mLeft, mRight, mUp, mDown;

    {
        gameMenu = new JMenu(Util.getResourceBundle().getString("menu.game"));
        mNewGame = new JMenuItem(Util.getResourceBundle().getString("menu.game.new"), 'N');
        mEnd = new JMenuItem(Util.getResourceBundle().getString("menu.game.end"), 'K');

        moveMenu = new JMenu(Util.getResourceBundle().getString("menu.movement"));
        mSelect = new JMenuItem(Util.getResourceBundle().getString("movement.select"));
        mLeft = new JMenuItem(Util.getResourceBundle().getString("movement.left"));
        mRight = new JMenuItem(Util.getResourceBundle().getString("movement.right"));
        mUp = new JMenuItem(Util.getResourceBundle().getString("movement.up"));
        mDown = new JMenuItem(Util.getResourceBundle().getString("movement.down"));

    }


    public MenuBar(Board board) {
        add();
        setAccelerator();
        setCommand();
        addListener(board);
        update(true);
    }

    private void add() {
        add(gameMenu);
        gameMenu.add(mNewGame);
        gameMenu.addSeparator();
        gameMenu.add(mEnd);

        add(moveMenu);
        moveMenu.add(mSelect);
        moveMenu.addSeparator();
        moveMenu.add(mLeft);
        moveMenu.add(mRight);
        moveMenu.add(mUp);
        moveMenu.add(mDown);

        add(Box.createGlue());
    }

    private void setAccelerator() {
        mSelect.setAccelerator(KeyStroke.getKeyStroke("SPACE"));
        mLeft.setAccelerator(KeyStroke.getKeyStroke("LEFT"));
        mRight.setAccelerator(KeyStroke.getKeyStroke("RIGHT"));
        mUp.setAccelerator(KeyStroke.getKeyStroke("UP"));
        mDown.setAccelerator(KeyStroke.getKeyStroke("DOWN"));
    }

    private void setCommand() {
        mNewGame.setActionCommand("NEW_GAME");
        mEnd.setActionCommand("GAME_OVER");
        mSelect.setActionCommand("SELECT");
        mLeft.setActionCommand("LEFT");
        mRight.setActionCommand("RIGHT");
        mUp.setActionCommand("UP");
        mDown.setActionCommand("DOWN");

    }

    private void addListener(Board board) {
        mSelect.addActionListener(new KeyListener(board));
        mLeft.addActionListener(new KeyListener(board));
        mRight.addActionListener(new KeyListener(board));
        mUp.addActionListener(new KeyListener(board));
        mDown.addActionListener(new KeyListener(board));
    }

    public void update(boolean enable) {
        mNewGame.setEnabled(enable);
    }

}

