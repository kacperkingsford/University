package util;

public enum Turn {
    MOVEMENT,
    SELECTION
}
