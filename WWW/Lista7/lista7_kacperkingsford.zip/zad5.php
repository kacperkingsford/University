<?php
    header('Content-Type: text/css');
?>
body {
    background-color: red;
}
