<?php
     //header('Content-Type: image/png');
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Zadanie 4</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    </head>

    <body>
        <h3>Headersy</h3>
    </body>
</html>
