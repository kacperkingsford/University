
using Plots
x = 1:10; y = rand(10);
plot(x, y)

png("plot.png") 